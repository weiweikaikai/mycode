#include <getopt.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <service.h>

int handle_init (int argc, char **argv, int pid_type)
{
	switch (pid_type)
    {
		case PROC_MAIN:
			return 0;
		case PROC_WORK:
			return 0;
		case PROC_CONN:
			return 0;
		case PROC_TIME:
			return 0;
		default:
			ERROR_LOG ("invalid pid_type=%d", pid_type);
			return -1;
	}

	return -1;
}

int handle_input (const char* buffer, int length, const skinfo_t *sk)
{
/*	struct in_addr addr;
	addr.s_addr = sk->remote_ip;	
	DEBUG_LOG ("recv from %s:%u %d bytes, package length=%d",
		inet_ntoa (addr), ntohs(sk->remote_port), length, length); 
*/    
    
	return *(uint32_t*)buffer;
}

int handle_process (char *recvbuf, int rcvlen, char **sendbuf, int *sndlen, const skinfo_t *sk)
{
	*sendbuf = (char*)malloc (rcvlen);
	if (! *sendbuf)
		ERROR_RETURN (("malloc error, %s", strerror (errno)), -1);

//	WARN_LOG("------- %d -------", *(int*)recvbuf);

	*sndlen = rcvlen;
	
	memcpy (*sendbuf, recvbuf, rcvlen);
	return 0;
}

int handle_timer(int* intvl)
{
	return 0;
}


int handle_filter_key (const char* buf, int len, uint32_t* key)
{
    return -1;
}

/*
typedef uint32_t userid_t;

typedef struct proto_header{
    uint32_t proto_length;
    uint32_t proto_id;
    uint16_t cmd_id;
    int32_t result;
    userid_t id;
} __attribute__((packed)) PROTO_HEADER;

int handle_filter_key (const char* buf, int len, uint32_t* key)
{
    if (len < sizeof(PROTO_HEADER))
        return -1;
    
    *key = ((PROTO_HEADER*)(buf))->id;
    return 0;
}
*/

int handle_open (char **buf, int *len, const skinfo_t* sk)
{
    return 0;
}

int handle_close (const skinfo_t* sk)
{
    return 0;
}

void handle_fini (int t)
{
}
